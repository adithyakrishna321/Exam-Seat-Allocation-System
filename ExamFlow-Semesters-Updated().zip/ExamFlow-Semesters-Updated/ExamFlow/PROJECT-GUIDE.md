# ExamFlow — admission years, semesters and updated logins

## Run a fresh installation

Requires Node.js 24 and npm. Extract the project and run:

```sh
npm ci
npm run db:setup
npm run db:accounts
npm run dev
```

Open http://localhost:5173 and select the correct login module.

| Module | Example email | Password |
|---|---|---|
| Administrator | admin@gmail.com | admin123 |
| Faculty — Arun Mathew | arunmathew@gmail.com | arunmathew123 |
| Student — Arun, 2022 BCA | arun@gmail.com | arun123 |
| Student — Arun, 2026 BCA | arun2026@gmail.com | arun123 |

All logins are recorded in `work/login-credentials.csv` after setup. Faculty use their complete name in lowercase without spaces, followed by @gmail.com; their password is the same name followed by 123. Students use their first name in lowercase, with password firstname123. Because first names repeat, duplicate emails receive the admission year and then a number if necessary (for example arun2022@gmail.com or arun20222@gmail.com). The CSV is the authoritative list for each student. These are application login identifiers, not newly created Gmail accounts. No emails are sent.

## Upgrade the previous version

Copy the updated source into your existing project while preserving its `.wrangler/state` and `work/local-d1.json`, then run:

```sh
npm ci
npm run db:upgrade
npm run dev
```

The local upgrade creates a SQL backup in `work/before-cohort-upgrade-*.sql`, preserves existing student/faculty records and exams, adds missing 2022-onward sample cohorts, updates semester metadata, resets the requested login credentials, and signs out existing sessions. It writes the updated login CSV. It refuses to initialize an empty campus; use fresh setup for a new installation. Re-running after a successful upgrade makes no changes. The current preview has already been upgraded.

## Courses and admission years

BCA is a four-year course with S1, S2, S3, S4, S5, S6, S7 and S8. MCA is a two-year course with S1, S2, S3 and S4.

The fixture includes admission years 2022, 2023, 2024, 2025 and 2026 for both courses: ten batches and 600 students. Each admission batch has 60 students with common boys' and girls' names. A student is created once for an admission year and progresses with that batch, rather than being duplicated across semesters.

The request mentioned both 2025 and 2022 for MCA; this version follows the repeated instruction to start at 2022 for both courses. As of the 2026–27 odd-semester example, BCA 2023/2024/2025/2026 are S7/S5/S3/S1, and MCA 2025/2026 are S3/S1. BCA 2022 and MCA 2022–2024 are marked Completed and retained as historical student records. Completed cohorts are excluded from new exam selection. Semester/status can be edited to match your actual academic calendar; there is no automatic semester advancement.

Roll numbers run from MLM22BCA01 to MLM22BCA60, MLM23BCA01 to MLM23BCA60, and so on through MLM26BCA60. MCA follows MLM22MCA01–MLM22MCA60 through MLM26MCA01–MLM26MCA60.

## Add upcoming years and students

1. Sign in as admin and open **Batches**.
2. Choose **Add upcoming-year batch**.
3. Select BCA or MCA, admission year, current semester and status. BCA permits S1–S8; MCA permits S1–S4. Admission years are supported from 2022 through 2100.
4. Leave the sample option unchecked to create an empty batch, or check **Generate 60 sample students** to create common names, roll numbers, unique login emails and name-based passwords.
5. For manual enrolment, open **Students → Enroll student** and select the new batch. The year and next roll number are filled when you choose it. Enter a name and select **Use name-based email & password**, review the details, and save.
6. Create an exam in **Exam schedule** and enter subjects for the participating active batches. Generate and publish seating.

The Students page includes batch and semester filters and displays admission year and current semester/status. The Batches page displays the full course semester sequence and student counts. **Edit semester / status** advances a group or marks it completed. Changing its semester/status unpublishes and clears affected seating plans; generate and publish again. A batch containing students or exam references cannot be deleted; mark it Completed to retain its history.

## Existing functionality

The public index contains the campus cover illustration and three login choices only. Admin record pages have edit/delete controls. Logout is available in every authenticated view and returns to the index. Students see their own published seats; faculty see assigned rooms and can record or clear attendance. Name-based defaults still use salted hashes and server-side role checks, database sessions, origin checks and login-attempt limits.

Deleting a student, assigned faculty member or classroom clears affected allocations. Changing a classroom name or exam also clears affected allocations. Delete allocation retains the exam definition. Removing an exam removes its dependent records. Adding students to an already allocated batch or moving students between allocated batches is blocked: clear the allocation, edit the register, then regenerate. Password resets revoke existing sessions. Editing a person's name does not silently change their login; the name-based login button explicitly fills the new values.

## Database and checks

Cloudflare D1 runs locally as SQLite in `.wrangler/state`. `database/examflow-sample.sqlite` is an inspection fixture containing all 600 students and a draft exam for the 360 currently active students. Ten rooms and twenty faculty are available; the sample active exam uses six rooms and twelve invigilators. Completed cohorts are not allocated to that exam.

Batch metadata is stored in SQL with course, admission year, semester and status. New years are persisted and work with enrolment, exam creation and seating without code changes. Writes use revision checks and transactions. Authentication and batch migrations are included under `drizzle/`; the local upgrade script also performs the necessary schema changes.

```sh
npm run typecheck
npm test
npm run build
```

With the development server running:

```sh
npm run test:api
node scripts/check-cohorts.mjs
```

API tests modify the local synthetic dataset and must only run against a disposable test database. Checks cover role access, login/logout, CRUD, password/session revocation, attendance, seating constraints, semester limits, historical cohorts, future-year generation/enrolment, semester-change invalidation and cleanup. This delivery is source code and local setup, with no hosted deployment.
