import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const base=process.env.EXAMFLOW_TEST_URL||'http://localhost:5173';
const accounts=readFileSync('work/login-credentials.csv','utf8').trim().split('\n').slice(1).map(s=>{const [role,name,email,password]=s.split(',').map(v=>v.replace(/^"|"$/g,''));return {role,name,email,password};});
async function login(a,expected=200){const r=await fetch(base+'/api/auth/login',{method:'POST',headers:{'Content-Type':'application/json',Origin:base},body:JSON.stringify(a)});const raw=await r.text();let body;try{body=JSON.parse(raw)}catch{body={error:raw}};assert.equal(r.status,expected,JSON.stringify(body));return r.headers.getSetCookie().map(x=>x.split(';')[0]).join('; ');}
const cookie=await login(accounts[0]);const headers={Cookie:cookie,'Content-Type':'application/json',Origin:base};
const get=async(cookieOverride=cookie)=>{const r=await fetch(base+'/api/workspace',{headers:{Cookie:cookieOverride}});const p=await r.json();assert.equal(r.status,200,JSON.stringify(p));return p};
assert.equal((await fetch(base+'/api/workspace')).status,403);
await login({...accounts[0],password:'incorrect-password'},401);await login({...accounts[0],role:'student'},401);
let p=await get();assert.equal(p.state.students.length,600);
async function post(action,extra={},expected=200,customHeaders=headers){const r=await fetch(base+'/api/workspace',{method:'POST',headers:customHeaders,body:JSON.stringify({action,revision:p.revision,sessionId:p.state.sessions[0]?.id,...extra})});const raw=await r.text();let body;try{body=JSON.parse(raw)}catch{body={error:raw}};assert.equal(r.status,expected,JSON.stringify(body));if(r.ok)p=body;return body;}
await post('delete',{kind:'allocation'});await post('generate');assert.equal(p.state.sessions[0].seats.length,360);await post('publish');
const stu=accounts.find(x=>x.role==='student'&&x.email==='arun2023@gmail.com'),faculty=accounts.find(x=>x.role==='faculty');
const sc=await login(stu),fc=await login(faculty);const sv=await get(sc),fv=await get(fc);assert.equal(sv.state.students.length,1);assert.equal(sv.state.sessions[0].seats.length,1);assert.equal(fv.state.faculty.length,1);assert.ok(fv.state.students.length<=60);
await post('room',{name:'UNAUTHORIZED'},400,{...headers,Cookie:sc});await post('delete',{kind:'student',id:sv.personId},400,{...headers,Cookie:fc});
await post('room',{name:'CSRF'},403,{...headers,Origin:'https://other.example'});
await post('room',{name:'STALE',revision:-1},400);
const seat=p.state.sessions[0].seats[0];await post('attendance',{studentId:seat.studentId,status:'Absent'});assert.equal((await get()).state.sessions[0].attendance[seat.studentId].status,'Absent');await post('attendance',{studentId:seat.studentId,status:'Not marked'});assert.equal(Object.keys((await get()).state.sessions[0].attendance).length,0);
const first=p.state.students[0];await post('student',{record:{...first,name:'Arun Test'}});assert.equal((await get()).state.students[0].name,'Arun Test');await post('student',{record:first});
await post('room',{name:'TESTROOM'});await post('room',{oldName:'TESTROOM',name:'EDITROOM'});assert.ok((await get()).state.rooms.includes('EDITROOM'));await post('delete',{kind:'room',id:'EDITROOM'});
const session={title:'Test exam',date:'2026-12-01',start:'09:00',end:'12:00',subjects:{'2026 BCA':'C'}};await post('session',{record:session});const added=p.state.sessions.find(s=>s.title==='Test exam');await post('session',{record:{...added,title:'Edited exam'}});assert.equal((await get()).state.sessions.find(s=>s.id===added.id).title,'Edited exam');await post('delete',{kind:'session',id:added.id});
await post('faculty',{record:{name:'Test Teacher',email:'teacher@test.example',password:'Teacher-password-123'}});const teacher=p.state.faculty.find(x=>x.email==='teacher@test.example');const tc=await login({role:'faculty',email:teacher.email,password:'Teacher-password-123'});await post('faculty',{record:{...teacher,email:'teacher2@test.example',password:'Changed-password-123'}});assert.equal((await fetch(base+'/api/workspace',{headers:{Cookie:tc}})).status,403);await login({role:'faculty',email:'teacher2@test.example',password:'Changed-password-123'});await post('delete',{kind:'faculty',id:teacher.id});await login({role:'faculty',email:'teacher2@test.example',password:'Changed-password-123'},401);
const allocatedRoom=p.state.sessions[0].seats[0].room;await post('room',{oldName:allocatedRoom,name:'RENAMED'});assert.equal(p.state.sessions[0].published,false);assert.equal(p.state.sessions[0].seats.length,0);await post('room',{oldName:'RENAMED',name:allocatedRoom});
await post('student',{record:{name:'Test Student',roll:'TEST01',batch:'2026 BCA',year:'2026',email:'student@test.example',password:'Student-password-123'}});const addedStudent=p.state.students.find(x=>x.roll==='TEST01');await login({role:'student',email:addedStudent.email,password:'Student-password-123'});await post('delete',{kind:'student',id:addedStudent.id});assert.equal((await get()).state.students.length,600);
await post('generate');await post('publish');
const logout=await fetch(base+'/api/auth/logout',{method:'POST',headers});assert.equal(logout.status,200);assert.equal((await fetch(base+'/api/workspace',{headers})).status,403);
console.log('PASS: all 3 roles, wrong-password and wrong-role denial, anonymous denial, record CRUD, allocation invalidation, password reset and session revocation, deleted-account denial, CSRF, stale-write protection, attendance, publication and logout.');

