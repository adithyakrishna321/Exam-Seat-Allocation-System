import {DatabaseSync} from 'node:sqlite';
import {readFileSync,writeFileSync,existsSync} from 'node:fs';
import {seed,generate} from '../lib/exams.ts';
const state=seed();state.sessions=state.sessions.map(session=>generate(state,session));
const quote=v=>v===null?'NULL':typeof v==='number'?String(v):"'"+String(v).replaceAll("'","''")+"'";
const insert=(table,cols,rows)=>rows.map(row=>`INSERT INTO ${table} (${cols.join(',')}) VALUES (${row.map(quote).join(',')});`).join('\n');
const sections=[
insert('batches',['id','department','semester','admission_year','status'],state.batches.map(b=>[b.id,b.department,b.semester,b.admissionYear,b.status])),
insert('students',['id','name','roll','batch','academic_year','email'],state.students.map(s=>[s.id,s.name,s.roll,s.batch,s.year,s.email])),
insert('faculty',['id','name','email'],state.faculty.map(f=>[f.id,f.name,f.email])),
insert('classrooms',['id','bench_count','seats_per_bench'],state.rooms.map(r=>[r,12,5])),
insert('exam_sessions',['id','title','exam_date','start_time','end_time','published'],state.sessions.map(s=>[s.id,s.title,s.date,s.start,s.end,0])),
insert('exam_subjects',['session_id','batch','subject'],state.sessions.flatMap(s=>Object.entries(s.subjects).map(([b,subject])=>[s.id,b,subject]))),
insert('seat_allocations',['session_id','student_id','room_id','bench','position','seat_number'],state.sessions.flatMap(s=>s.seats.map(a=>[s.id,a.studentId,a.room,a.bench,a.position,a.number]))),
insert('invigilator_assignments',['session_id','room_id','faculty_id'],state.sessions.flatMap(s=>Object.entries(s.duties).flatMap(([r,ids])=>ids.map(id=>[s.id,r,id])))),
];
const sample='-- Synthetic sample data only. Import into an empty schema for SQL exploration.\nBEGIN;\n'+sections.join('\n')+'\nCOMMIT;\n';writeFileSync('database/sample-data.sql',sample);
const db=new DatabaseSync(':memory:');db.exec('PRAGMA foreign_keys=ON');db.exec(readFileSync('database/schema.sql','utf8'));db.exec(sample);
if(db.prepare('PRAGMA foreign_key_check').all().length)throw Error('Foreign key check failed');
const students=db.prepare('SELECT COUNT(*) AS n FROM students').get();if(students.n!==state.students.length)throw Error(`Expected ${state.students.length} seeded students`);
const count=db.prepare('SELECT COUNT(*) AS n FROM seat_allocations').get();if(count.n!==state.students.length)throw Error(`Expected ${state.students.length} seats`);
const expectedDuties=state.sessions.reduce((total,session)=>total+Object.values(session.duties).flat().length,0);const duties=db.prepare('SELECT COUNT(*) AS n FROM invigilator_assignments').get();if(duties.n!==expectedDuties)throw Error(`Expected ${expectedDuties} faculty assignments`);
const mcaS3=state.batches.find(batch=>batch.department==='MCA'&&batch.semester===3);if(db.prepare('SELECT COUNT(*) AS n FROM students WHERE batch=?').get(mcaS3.id).n!==59)throw Error('Expected 59 MCA S3 students');
if(existsSync('database/examflow-bca-mca-sample.sqlite'))throw Error('BCA/MCA sample SQLite file already exists and was not overwritten.');
db.exec("VACUUM INTO 'database/examflow-bca-mca-sample.sqlite'");db.close();console.log(`SQL sample database verified: ${state.students.length} students, ${state.students.length} seats, ${expectedDuties} faculty assignments; all foreign keys valid.`);
