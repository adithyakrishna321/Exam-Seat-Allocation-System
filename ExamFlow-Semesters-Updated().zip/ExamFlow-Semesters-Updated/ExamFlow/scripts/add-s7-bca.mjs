import {mkdirSync,writeFileSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import {batchId,createRosterStudents,defaultPassword,loginName} from '../lib/exams.ts';
import {s7BcaNames} from '../lib/bca-roster.ts';
import {hashPassword,verifyPassword} from '../lib/passwords.ts';

mkdirSync('work',{recursive:true});
const args=['--import','./scripts/sites-env.mjs','./node_modules/wrangler/bin/wrangler.js','d1','execute','DB','--local','--config','work/local-d1.json','--persist-to','.wrangler/state'];
function execute(extra){const result=spawnSync(process.execPath,[...args,...extra],{encoding:'utf8',maxBuffer:20*1024*1024});if(result.status!==0)throw Error(result.stderr||result.stdout);return result.stdout;}
const query=sql=>JSON.parse(execute(['--command',sql,'--json']))[0].results;
const quote=value=>value===null?'NULL':"'"+String(value).replaceAll("'","''")+"'";
const id=batchId(2023,'BCA','A');
if(!query('SELECT id FROM campus WHERE id=1').length)throw Error('Initialize the local database before adding the S7 BCA batch.');
const sessions=query("SELECT id,title,published FROM exam_sessions WHERE id IN ('session-1','session-2')");
if(sessions.length!==2)throw Error('Both examination sessions are required before adding S7 BCA.');
for(const session of sessions)if(session.published||query(`SELECT student_id FROM seat_allocations WHERE session_id=${quote(session.id)}`).length)throw Error('Clear existing examination allocations before changing rosters or titles.');
const existing=query(`SELECT s.id,s.name,s.roll,s.batch,s.academic_year,s.email,a.role,a.person_id,a.password_hash FROM students s LEFT JOIN accounts a ON a.id=s.id WHERE s.batch=${quote(id)} ORDER BY s.roll`);
if(existing.length&&existing.length!==s7BcaNames.length)throw Error('The existing S7 division does not contain exactly 60 students; no data was changed.');
for(const student of existing)if(student.batch!==id||student.role!=='student'||student.person_id!==student.id)throw Error(`Existing S7 student ${student.id} has an unexpected account or batch link; no data was changed.`);
const currentBatch=query(`SELECT department,semester,admission_year,status FROM batches WHERE id=${quote(id)}`)[0];
const currentSubject=query(`SELECT subject FROM exam_subjects WHERE session_id='session-1' AND batch=${quote(id)}`)[0];
const batch={id,department:'BCA',admissionYear:2023,semester:7,status:'Active',division:'A'};
const used=new Set(query('SELECT email FROM students WHERE email IS NOT NULL UNION SELECT email FROM faculty WHERE email IS NOT NULL').map(row=>row.email));
const students=existing.length?existing.map((student,index)=>({...student,name:s7BcaNames[index],year:String(student.academic_year)})):createRosterStudents(batch,s7BcaNames,used);
if(!existing.length){
 const rolls=students.map(student=>quote(student.id)).join(',');
 if(query(`SELECT id FROM accounts WHERE id IN (${rolls})`).length)throw Error('A requested S7 student account ID is already occupied; no data was changed.');
 if(query(`SELECT id FROM students WHERE roll IN (${students.map(student=>quote(student.roll)).join(',')})`).length)throw Error('A requested S7 roll number is already in use; no data was changed.');
}
let sql='';let changed=!currentBatch||currentBatch.department!=='BCA'||currentBatch.semester!==7||currentBatch.admission_year!==2023||currentBatch.status!=='Active';
if(changed)sql+=`INSERT INTO batches (id,department,semester,admission_year,status) VALUES (${quote(id)},'BCA',7,2023,'Active') ON CONFLICT(id) DO UPDATE SET department='BCA',semester=7,admission_year=2023,status='Active';\n`;
const credentials=['Username,Password,Roll number,Name'];
for(const [index,student] of students.entries()){
 const password=defaultPassword(student.name,'student');
 credentials.push([loginName(student.name),password,student.roll,student.name].map(value=>'"'+String(value).replaceAll('"','""')+'"').join(','));
 if(!existing.length){
  const hash=await hashPassword(password);
  sql+=`INSERT INTO students (id,name,roll,batch,academic_year,email) VALUES (${[student.id,student.name,student.roll,id,student.year,student.email].map(quote).join(',')});\n`;
  sql+=`INSERT INTO accounts (id,role,person_id,email,password_hash) VALUES (${quote(student.id)},'student',${quote(student.id)},NULL,${quote(hash)});\n`;
  changed=true;
 }else{
  if(existing[index].name!==student.name){sql+=`UPDATE students SET name=${quote(student.name)} WHERE id=${quote(student.id)};\n`;changed=true;}
  if(!await verifyPassword(password,student.password_hash||'')){const hash=await hashPassword(password);sql+=`UPDATE accounts SET password_hash=${quote(hash)} WHERE id=${quote(student.id)};\nDELETE FROM auth_sessions WHERE account_id=${quote(student.id)};\n`;changed=true;}
 }
}
if(currentSubject?.subject!=='Computer science'){sql+=`INSERT INTO exam_subjects (session_id,batch,subject) VALUES ('session-1',${quote(id)},'Computer science') ON CONFLICT(session_id,batch) DO UPDATE SET subject='Computer science';\n`;changed=true;}
for(const session of sessions){const title=session.id==='session-1'?'BCA series examinations':'MCA series examinations';if(session.title!==title){sql+=`UPDATE exam_sessions SET title=${quote(title)} WHERE id=${quote(session.id)};\n`;changed=true;}}
if(changed){sql+='UPDATE campus SET revision=revision+1 WHERE id=1;\n';writeFileSync('work/add-s7-bca.sql',sql);execute(['--file','work/add-s7-bca.sql']);}
writeFileSync('work/s7-bca-credentials.csv',credentials.join('\n')+'\n');
console.log(`${existing.length?`Updated ${students.length} existing students`:`Added ${students.length} students`} in S7 BCA ${id}; ${changed?'database updated':'no database changes were needed'}. Credentials: work/s7-bca-credentials.csv.`);