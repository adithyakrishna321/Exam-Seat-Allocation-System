import {mkdirSync,readFileSync,writeFileSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
mkdirSync('work',{recursive:true});
const sql=readFileSync('database/schema.sql','utf8').replaceAll('CREATE TABLE `','CREATE TABLE IF NOT EXISTS `').replaceAll('CREATE UNIQUE INDEX `','CREATE UNIQUE INDEX IF NOT EXISTS `');
writeFileSync('work/schema-local.sql',sql);
writeFileSync('work/local-d1.json',JSON.stringify({name:'examflow-local',compatibility_date:'2026-05-15',d1_databases:[{binding:'DB',database_name:'site-creator-d1',database_id:'00000000-0000-4000-8000-000000000000'}]}));
const r=spawnSync(process.execPath,['--import','./scripts/sites-env.mjs','./node_modules/wrangler/bin/wrangler.js','d1','execute','DB','--local','--config','work/local-d1.json','--persist-to','.wrangler/state','--file','work/schema-local.sql'],{stdio:'inherit'});
if(r.error)throw r.error;process.exitCode=r.status||0;
