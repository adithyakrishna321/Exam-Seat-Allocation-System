// Upgrade the earlier local ExamFlow preview without deleting its records.
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import {seed,uniqueEmail,defaultPassword} from '../lib/exams.ts';
import {hashPassword} from '../lib/passwords.ts';
mkdirSync('work',{recursive:true});
const prefix=['--import','./scripts/sites-env.mjs','./node_modules/wrangler/bin/wrangler.js','d1'];
const config=['DB','--local','--config','work/local-d1.json','--persist-to','.wrangler/state'];
function run(args){const p=spawnSync(process.execPath,[...prefix,...args],{encoding:'utf8',maxBuffer:20*1024*1024});if(p.status!==0)throw Error(p.stderr||p.stdout);return p.stdout;}
const query=sql=>JSON.parse(run(['execute',...config,'--command',sql,'--json']))[0].results;
const columns=query('PRAGMA table_info(batches)');
const existingStudents=query('SELECT * FROM students');
const existingFaculty=query('SELECT * FROM faculty');
if(!query('SELECT * FROM campus').length)throw Error('No initialized campus found. Use db:setup and db:accounts for a fresh installation.');
if(columns.some(c=>c.name==='admission_year')&&query("SELECT id FROM accounts WHERE role='admin' AND email='admin@gmail.com'").length&&existingStudents.length>=seed().students.length){console.log('This database is already upgraded. No records or credentials were changed.');process.exit(0);}
const backup='work/before-cohort-upgrade-'+Date.now()+'.sql';
run(['export',...config.slice(0,4),'--output',backup]);
const state=seed();
const students=[...state.students.map(st=>{const previous=existingStudents.find(p=>p.id===st.id);return previous?{...st,...previous,year:previous.academic_year}:st;}),...existingStudents.filter(p=>!state.students.some(st=>st.id===p.id)).map(p=>({...p,year:p.academic_year}))];
const faculty=[...existingFaculty];
const used=new Set(['admin@gmail.com']);
for(const f of faculty)f.email=uniqueEmail(f.name,'faculty',2026,used);
for(const st of students)st.email=uniqueEmail(st.name,'student',Number(st.year)||2026,used);
const quote=v=>v===null?'NULL':"'"+String(v).replaceAll("'","''")+"'";
let sql='';
if(!columns.some(c=>c.name==='admission_year'))sql+="ALTER TABLE batches ADD COLUMN admission_year INTEGER NOT NULL DEFAULT 2026;\n";
if(!columns.some(c=>c.name==='status'))sql+="ALTER TABLE batches ADD COLUMN status TEXT NOT NULL DEFAULT 'Active';\n";
sql+="UPDATE batches SET admission_year=CAST(substr(id,1,4) AS INTEGER);\n";
for(const b of state.batches)sql+=`INSERT INTO batches (id,department,semester,admission_year,status) VALUES (${quote(b.id)},${quote(b.department)},${b.semester},${b.admissionYear},${quote(b.status)}) ON CONFLICT(id) DO UPDATE SET semester=excluded.semester,admission_year=excluded.admission_year,status=excluded.status;\n`;
// Null the old login IDs first to avoid transient uniqueness collisions when swapping names.
sql+='UPDATE students SET email=NULL;\nUPDATE faculty SET email=NULL;\nDELETE FROM auth_sessions;\nDELETE FROM login_attempts;\n';
for(const st of students)sql+=`INSERT INTO students (id,name,roll,batch,academic_year,email) VALUES (${[st.id,st.name,st.roll,st.batch,st.year,st.email].map(quote).join(',')}) ON CONFLICT(id) DO UPDATE SET email=excluded.email;\n`;
for(const f of faculty)sql+=`UPDATE faculty SET email=${quote(f.email)} WHERE id=${quote(f.id)};\n`;
const accounts=[{id:'admin',role:'admin',name:'Administrator',email:'admin@gmail.com'},...faculty.map(f=>({...f,role:'faculty'})),...students.map(st=>({...st,role:'student'}))];
const csv=[['Role','Name','Email','Password','Roll number','Batch']];
for(const a of accounts){const password=a.role==='admin'?'admin123':defaultPassword(a.name,a.role);const hash=await hashPassword(password);sql+=`INSERT INTO accounts (id,role,person_id,email,password_hash) VALUES (${quote(a.id)},${quote(a.role)},${a.role==='admin'?'NULL':quote(a.id)},${a.role==='admin'?quote(a.email):'NULL'},${quote(hash)}) ON CONFLICT(id) DO UPDATE SET email=excluded.email,password_hash=excluded.password_hash;\n`;csv.push([a.role,a.name,a.email,password,a.roll||'',a.batch||'']);}
sql+="UPDATE campus SET owner='admin@gmail.com',revision=revision+1 WHERE id=1;\n";
writeFileSync('work/upgrade-cohorts.sql',sql);
run(['execute',...config,'--file','work/upgrade-cohorts.sql']);
writeFileSync('work/login-credentials.csv',csv.map(r=>r.map(v=>'"'+String(v).replaceAll('"','""')+'"').join(',')).join('\n')+'\n');
console.log(`Upgraded ${students.length} students and ${faculty.length} faculty. Backup: ${backup}. Updated logins: work/login-credentials.csv`);

