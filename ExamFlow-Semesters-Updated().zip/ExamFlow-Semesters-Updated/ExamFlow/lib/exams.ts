import {bcaS3Names,mcaS3Names,s1BcaNames,s1McaNames,s3McaNames,s5BcaNames,s7BcaNames} from './bca-roster.ts';
export const batches=['S1 BCA','S3 BCA','S5 BCA','2023 BCA A','S1 MCA','S3 MCA'];
export type Batch={id:string;department:'BCA'|'MCA';admissionYear:number;semester:number;status:'Active'|'Completed';division:string};
export const semesterCount=(course:string)=>course==='BCA'?8:4;
export const batchId=(admissionYear:number,department:string,division='A')=>`${admissionYear} ${department} ${division}`;
export const batchDivision=(id:string)=>id.match(/^\d{4}\s+(?:BCA|MCA)\s+([A-Z])$/)?.[1]||'A';
export const batchDepartment=(id:string):'BCA'|'MCA'=>id.match(/(?:^|\s)(BCA|MCA)(?:\s+[A-Z])?$/)?.[1] as 'BCA'|'MCA'||(id.includes('MCA')?'MCA':'BCA');
export const loginName=(name:string)=>name.toLowerCase().replace(/[^a-z]/g,'');
export const usernameFromName=(name:string)=>loginName(name || '');
export const batchDisplayName=(batch:Batch)=>`S${batch.semester} ${batch.department} · Division ${batch.division||batchDivision(batch.id)}`;
export const defaultPassword=(name:string,role:string)=>{
  if(role==='admin')return 'admin123';
  const username=usernameFromName(name);
  return username ? username+'123' : 'user123';
};
export function uniqueEmail(name:string,role:string,year:number,used:Set<string>){const base=loginName(role==='faculty'?name:name.split(/\s+/)[0]);let local=base;let n=1;while(used.has(local+'@gmail.com')){local=base+year+(n===1?'':String(n));n++;}const email=local+'@gmail.com';used.add(email);return email;}
export type Student={id:string;name:string;roll:string;batch:string;year:string;email:string};
export type Faculty={id:string;name:string;email:string};
export type Seat={studentId:string;room:string;bench:number;position:number;number:number};
export type AttendanceReport={by:string;at:string};
export type Session={id:string;title:string;date:string;start:string;end:string;subjects:Record<string,string>;published:boolean;seats:Seat[];duties:Record<string,string[]>;attendance:Record<string,{status:string;by:string;at:string}>;attendanceReports:Record<string,AttendanceReport>};
export type State={batches:Batch[];students:Student[];faculty:Faculty[];rooms:string[];sessions:Session[]};
export function validateDivisionCapacity(state:Pick<State,'batches'|'students'>){const counts=new Map<string,number>();for(const student of state.students)counts.set(student.batch,(counts.get(student.batch)||0)+1);for(const batch of state.batches)if((counts.get(batch.id)||0)>60)throw Error('A division cannot contain more than 60 students. Add another division for this admission year.');}
export function submitAttendanceReport(session:Session,room:string,facultyId:string,facultyName:string,at=new Date().toISOString()){if(!session.published)throw Error('Publish the examination before submitting attendance.');if(!session.duties[room]?.includes(facultyId))throw Error('You are not assigned to this classroom.');const roster=session.seats.filter(seat=>seat.room===room);if(!roster.length)throw Error('This classroom has no allocated students.');if(roster.some(seat=>!['Present','Absent'].includes(session.attendance[seat.studentId]?.status||'')))throw Error('Mark every student present or absent before saving the report.');session.attendanceReports[room]={by:facultyName,at};return session.attendanceReports[room];}
const boys=['Arun','Rahul','Arjun','Vishnu','Amal','Anil','Akhil','Ajay','Vijay','Ravi','Manu','Kiran','Nithin','Rohit','Sanjay','Adithya','Deepak','Anand','Rakesh','Suresh','Hari','Varun','Ashwin','Abin','Kevin','Alan','Joel','John','David','Sam'];
const girls=['Anu','Anna','Priya','Neha','Anjali','Divya','Meera','Sneha','Pooja','Riya','Diya','Maya','Asha','Nisha','Kavya','Lakshmi','Sara','Mary','Rose','Nimisha','Anjana','Athira','Arya','Gopika','Devika','Reshma','Swathi','Veena','Sana','Fathima'];
const surnames=['Kumar','Nair','Menon','Das','Thomas','Joseph','Rajan','Paul','Shah','Roy','Iyer','Varghese','George','Jacob','Nandan','Prakash','Sarma','Khan','Dutta','Fernandes'];
const facultyNames=['ashwani','athira','anju','kavitha','anjaly','ambili','sreelakshmi','silpa','sahira','minnu','eldhose'];
export function createBatchStudents(batch:Batch,used:Set<string>,offset=0):Student[]{const division=batch.division||batchDivision(batch.id);return Array.from({length:60},(_,i)=>{const roll='MLM'+String(batch.admissionYear).slice(-2)+batch.department+(division==='A'?'':division)+String(i+1).padStart(2,'0');const name=(i%2?girls:boys)[Math.floor(i/2)]+' '+surnames[offset%surnames.length];return {id:roll,name,roll,batch:batch.id,year:String(batch.admissionYear),email:uniqueEmail(name,'student',batch.admissionYear,used)};});}
export function createRosterStudents(batch:Batch,names:string[],used:Set<string>):Student[]{return names.map((name,i)=>{const roll='MLM'+String(batch.admissionYear).slice(-2)+batch.department+String(i+1).padStart(3,'0');return {id:roll,name,roll,batch:batch.id,year:String(batch.admissionYear),email:uniqueEmail(name,'student',batch.admissionYear,used)};});}
export function seed():State{
 const cohort:Batch[]=[
  {id:'S1 BCA',department:'BCA',admissionYear:2026,semester:1,status:'Active',division:'A'},
  {id:'S3 BCA',department:'BCA',admissionYear:2025,semester:3,status:'Active',division:'A'},
  {id:'S5 BCA',department:'BCA',admissionYear:2024,semester:5,status:'Active',division:'A'},
  {id:'2023 BCA A',department:'BCA',admissionYear:2023,semester:7,status:'Active',division:'A'},
  {id:'S1 MCA',department:'MCA',admissionYear:2026,semester:1,status:'Active',division:'A'},
  {id:'S3 MCA',department:'MCA',admissionYear:2025,semester:3,status:'Active',division:'A'},
 ];
 const used=new Set(['admin@gmail.com']);
 const faculty=facultyNames.map((name,i)=>({id:'F'+(i+1),name,email:uniqueEmail(name,'faculty',2026,used)}));
 const rosterByBatch:Record<string,string[]>={'S1 BCA':s1BcaNames,'S3 BCA':bcaS3Names,'S5 BCA':s5BcaNames,'2023 BCA A':s7BcaNames,'S1 MCA':s1McaNames,'S3 MCA':s3McaNames,'2025 MCA':mcaS3Names};
 const students=cohort.flatMap(b=>createRosterStudents(b,rosterByBatch[b.id]||[],used));
 const bcaSubjects=Object.fromEntries(cohort.filter(b=>b.status==='Active'&&b.department==='BCA').map(b=>[b.id,'Computer science']));
 const mcaSubjects=Object.fromEntries(cohort.filter(b=>b.status==='Active'&&b.department==='MCA').map(b=>[b.id,'Advanced programming']));
 return {batches:cohort,students,faculty,rooms:Array.from({length:10},(_,i)=>'R'+String(i+1).padStart(2,'0')),sessions:[{id:'session-1',title:'BCA series examinations',date:'2026-10-12',start:'09:30',end:'12:30',subjects:bcaSubjects,published:false,seats:[],duties:{},attendance:{},attendanceReports:{}},{id:'session-2',title:'MCA series examinations',date:'2026-10-13',start:'09:30',end:'12:30',subjects:mcaSubjects,published:false,seats:[],duties:{},attendance:{},attendanceReports:{}}]};
}
const assert=(condition:unknown,message:string)=>{if(!condition)throw new Error(message)};
export function generate(state:State,session:Session):Session{
 assert(!session.published,'Published sessions are locked. Create a new session for a revised plan.');
 const students=state.students.filter(s=>s.batch in session.subjects).sort((a,b)=>a.roll.localeCompare(b.roll));
 assert(students.length>0,'No students are registered in the selected batches.');
 let seats:Seat[]=[];
 if(new Set(students.map(student=>batchDepartment(student.batch))).size===1){
 assert(students.length<=state.rooms.length*60,'Insufficient classrooms for the mixing rules. Add classrooms or split this session.');
 seats=students.map((student,i)=>{const seatIndex=i%60,room=state.rooms[Math.floor(i/60)];return {studentId:student.id,room,bench:Math.floor(seatIndex/5)+1,position:seatIndex%5+1,number:seatIndex+1};});
 }else{
 const queues=state.batches.map(batch=>students.filter(s=>s.batch===batch.id));let roomIndex=0;
 while(queues.some(q=>q.length)){
 assert(roomIndex<state.rooms.length,'Insufficient classrooms for the mixing rules. Add classrooms or split this session.');
 const mq=queues.filter(q=>q[0]&&batchDepartment(q[0].batch)==='MCA').sort((a,b)=>b.length-a.length)[0];
 const bq=(mq?queues.find(q=>q[0]?.batch===mq[0].batch.replace('MCA','BCA')):undefined)||queues.filter(q=>q[0]&&batchDepartment(q[0].batch)==='BCA').sort((a,b)=>b.length-a.length)[0];
 const a=mq||bq,b=mq?bq:queues.filter(q=>q!==a&&q.length).sort((x,y)=>y.length-x.length)[0];const room=state.rooms[roomIndex++];
 for(let bench=1;bench<=12;bench++)for(let position=1;position<=5;position++){
 const wanted=(bench+position)%2===0?a:b,alternate=wanted===a?b:a;let q=wanted?.length?wanted:undefined;
 if(!q&&alternate?.[0]&&batchDepartment(alternate[0].batch)==='BCA')q=alternate;
 if(q?.length)seats.push({studentId:q.shift()!.id,room,bench,position,number:(bench-1)*5+position});}
 }
 }
 const rooms=[...new Set(seats.map(s=>s.room))];
 const overlapping=state.sessions.filter(s=>s.id!==session.id&&s.date===session.date&&s.start<session.end&&session.start<s.end);
 const occupied=new Set(overlapping.flatMap(s=>Object.values(s.duties).flat()));
 assert(!rooms.some(r=>overlapping.some(s=>s.seats.some(a=>a.room===r))),'A classroom is already allocated in an overlapping session.');
 assert(!students.some(st=>overlapping.some(s=>s.seats.some(a=>a.studentId===st.id))),'A student has an exam in an overlapping session.');
 const duties=(id:string)=>state.sessions.reduce((n,s)=>n+Object.values(s.duties).flat().filter(x=>x===id).length,0);
 const faculty=state.faculty.filter(f=>!occupied.has(f.id)).sort((a,b)=>duties(a.id)-duties(b.id));
 assert(faculty.length>=rooms.length*2,`Need ${rooms.length*2} available invigilators; only ${faculty.length} are available.`);
 const result={...session,seats,duties:Object.fromEntries(rooms.map((room,index)=>[room,[faculty[index*2].id,faculty[index*2+1].id]])),attendance:{},attendanceReports:{}};validate(state,result);return result;
}
export function validate(state:State,s:Session){
 const expected=state.students.filter(x=>x.batch in s.subjects);assert(s.seats.length===expected.length&&s.seats.length>0,'Every registered student must receive one seat.');
 const mixedCourses=expected.some(x=>batchDepartment(x.batch)==='BCA')&&expected.some(x=>batchDepartment(x.batch)==='MCA');
 assert(new Set(s.seats.map(x=>x.studentId)).size===s.seats.length,'Duplicate student allocation.');assert(expected.every(x=>s.seats.some(a=>a.studentId===x.id)),'A registered student is missing.');
 assert(new Set(s.seats.map(x=>`${x.room}-${x.number}`)).size===s.seats.length,'Duplicate seat.');
 for(const room of new Set(s.seats.map(x=>x.room))){const rows=s.seats.filter(x=>x.room===room);assert(rows.length<=60,'Room exceeds 60 seats.');assert(s.duties[room]?.length===2&&new Set(s.duties[room]).size===2,'Each room needs exactly two distinct invigilators.');for(const seat of rows){if(mixedCourses&&batchDepartment(state.students.find(x=>x.id===seat.studentId)!.batch)==='MCA')assert(!rows.some(x=>x.bench===seat.bench&&Math.abs(x.position-seat.position)===1&&state.students.find(st=>st.id===x.studentId)&&batchDepartment(state.students.find(st=>st.id===x.studentId)!.batch)==='MCA'),'Adjacent MCA students.');}}
 const staff=Object.values(s.duties).flat();assert(new Set(staff).size===staff.length,'Invigilator assigned to multiple rooms.');assert(staff.every(id=>state.faculty.some(f=>f.id===id)),'Unknown faculty member.');
}
