import {env} from 'cloudflare:workers';
import {tokenHash} from './passwords';
export type Identity={id:string;role:'admin'|'faculty'|'student';person_id:string|null;email:string};
export function database(){if(!env.DB)throw Error('Database unavailable.');return env.DB;}
export function sameOrigin(request:Request){const origin=request.headers.get('origin');if(origin&&origin!==new URL(request.url).origin)throw Error('Invalid request origin.');}
export function cookieToken(request:Request){return request.headers.get('cookie')?.split(';').map(x=>x.trim()).find(x=>x.startsWith('examflow_session='))?.slice(17)||'';}
export async function identity(request:Request):Promise<Identity|null>{
 const token=cookieToken(request);if(!/^[a-f0-9]{64}$/.test(token))return null;
 return database().prepare(`SELECT a.id,a.role,a.person_id,CASE WHEN a.role='student' THEN st.email WHEN a.role='faculty' THEN f.email ELSE a.email END AS email
 FROM auth_sessions s JOIN accounts a ON a.id=s.account_id
 LEFT JOIN students st ON a.role='student' AND st.id=a.person_id
 LEFT JOIN faculty f ON a.role='faculty' AND f.id=a.person_id
 WHERE s.token_hash=? AND s.expires_at>? AND (a.role='admin' OR st.id IS NOT NULL OR f.id IS NOT NULL)`)
 .bind(await tokenHash(token),Date.now()).first<Identity>();
}
export function sessionCookie(request:Request,token:string,maxAge:number){return `examflow_session=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${maxAge}${new URL(request.url).protocol==='https:'?'; Secure':''}`;}
