const encoder = new TextEncoder();
const hex = (bytes: ArrayBuffer) => Array.from(new Uint8Array(bytes), b => b.toString(16).padStart(2, '0')).join('');
export async function hashPassword(password: string, salt = hex(crypto.getRandomValues(new Uint8Array(16)).buffer)) {
  if (password.length < 6 || password.length > 128) throw Error('Use a password of 6–128 characters.');
  const key = await crypto.subtle.importKey('raw', encoder.encode(password), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({name:'PBKDF2',salt:encoder.encode(salt),iterations:100000,hash:'SHA-256'},key,256);
  return `pbkdf2$100000$${salt}$${hex(bits)}`;
}
export async function verifyPassword(password: string, stored: string) {
  if (typeof password !== 'string' || password.length < 6 || password.length > 128) return false;
  const parts = stored.split('$');
  if(parts.length!==4 || parts[0]!=='pbkdf2' || parts[1]!=='100000') return false;
  const actual=await hashPassword(password,parts[2]);
  let diff=actual.length^stored.length;
  for(let i=0;i<actual.length;i++) diff|=actual.charCodeAt(i)^(stored.charCodeAt(i)||0);
  return diff===0;
}
export async function tokenHash(token:string){return hex(await crypto.subtle.digest('SHA-256',encoder.encode(token)));}
