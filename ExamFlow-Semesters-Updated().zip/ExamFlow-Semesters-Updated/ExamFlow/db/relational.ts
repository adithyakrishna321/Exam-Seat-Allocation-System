import {env} from 'cloudflare:workers';
import {batchDivision,validateDivisionCapacity,type State} from '../lib/exams';
type RecordRow=Record<string,string|number|null>;
const configs=[
 ['batches',['id','department','semester','admission_year','status'],['id']],
 ['students',['id','name','roll','batch','academic_year','email'],['id']],
 ['faculty',['id','name','email'],['id']],
 ['classrooms',['id','bench_count','seats_per_bench'],['id']],
 ['exam_sessions',['id','title','exam_date','start_time','end_time','published'],['id']],
 ['exam_subjects',['session_id','batch','subject'],['session_id','batch']],
 ['seat_allocations',['session_id','student_id','room_id','bench','position','seat_number'],['session_id','student_id']],
 ['invigilator_assignments',['session_id','room_id','faculty_id'],['session_id','faculty_id']],
 ['attendance',['session_id','student_id','status','marked_by','marked_at'],['session_id','student_id']],
 ['attendance_reports',['session_id','room_id','submitted_by','submitted_at'],['session_id','room_id']],
] as const;
function raw(){if(!env.DB)throw Error('The database is unavailable. Please retry later.');return env.DB}
function flatten(s:State):Record<string,RecordRow[]>{return {
 batches:s.batches.map(b=>({id:b.id,department:b.department,semester:b.semester,admission_year:b.admissionYear,status:b.status})),
 students:s.students.map(x=>({id:x.id,name:x.name,roll:x.roll,batch:x.batch,academic_year:x.year,email:x.email||null})),
 faculty:s.faculty.map(x=>({id:x.id,name:x.name,email:x.email||null})),
 classrooms:s.rooms.map(id=>({id,bench_count:12,seats_per_bench:5})),
 exam_sessions:s.sessions.map(x=>({id:x.id,title:x.title,exam_date:x.date,start_time:x.start,end_time:x.end,published:Number(x.published)})),
 exam_subjects:s.sessions.flatMap(s=>Object.entries(s.subjects).map(([batch,subject])=>({session_id:s.id,batch,subject}))),
 seat_allocations:s.sessions.flatMap(s=>s.seats.map(a=>({session_id:s.id,student_id:a.studentId,room_id:a.room,bench:a.bench,position:a.position,seat_number:a.number}))),
 invigilator_assignments:s.sessions.flatMap(s=>Object.entries(s.duties).flatMap(([room_id,ids])=>ids.map(faculty_id=>({session_id:s.id,room_id,faculty_id})))),
 attendance:s.sessions.flatMap(s=>Object.entries(s.attendance).filter(([,a])=>a.status!=='Not marked').map(([student_id,a])=>({session_id:s.id,student_id,status:a.status,marked_by:a.by,marked_at:a.at}))),
 attendance_reports:s.sessions.flatMap(s=>Object.entries(s.attendanceReports).map(([room,report])=>({session_id:s.id,room_id:room,submitted_by:report.by,submitted_at:report.at}))),
}}
export async function readCampus(){const db=raw();
 const result=await db.batch([db.prepare('SELECT owner,revision FROM campus WHERE id=1'),...configs.map(([table])=>db.prepare(`SELECT * FROM ${table} ORDER BY rowid`))]);
 if(!result[0].results.length)throw Error('Run npm run db:setup and npm run db:accounts before signing in.');
 const campus=result[0].results[0] as {owner:string;revision:number};const rows=Object.fromEntries(configs.map(([table],i)=>[table,result[i+1].results as RecordRow[]]));
 const state:State={batches:rows.batches.map(b=>({id:String(b.id),department:String(b.department) as 'BCA'|'MCA',semester:Number(b.semester),admissionYear:Number(b.admission_year),status:String(b.status) as 'Active'|'Completed',division:batchDivision(String(b.id))})),students:rows.students.map(x=>({id:String(x.id),name:String(x.name),roll:String(x.roll),batch:String(x.batch),year:String(x.academic_year),email:String(x.email||'')})),faculty:rows.faculty.map(x=>({id:String(x.id),name:String(x.name),email:String(x.email||'')})),rooms:rows.classrooms.map(x=>String(x.id)).sort(),sessions:rows.exam_sessions.map(x=>({id:String(x.id),title:String(x.title),date:String(x.exam_date),start:String(x.start_time),end:String(x.end_time),published:!!x.published,subjects:Object.fromEntries(rows.exam_subjects.filter(a=>a.session_id===x.id).map(a=>[String(a.batch),String(a.subject)])),seats:rows.seat_allocations.filter(a=>a.session_id===x.id).map(a=>({studentId:String(a.student_id),room:String(a.room_id),bench:Number(a.bench),position:Number(a.position),number:Number(a.seat_number)})),duties:rows.invigilator_assignments.filter(a=>a.session_id===x.id).reduce((all,a)=>({...all,[String(a.room_id)]:[...(all[String(a.room_id)]||[]),String(a.faculty_id)]}),{} as Record<string,string[]>),attendance:Object.fromEntries(rows.attendance.filter(a=>a.session_id===x.id).map(a=>[String(a.student_id),{status:String(a.status),by:String(a.marked_by),at:String(a.marked_at)}])),attendanceReports:Object.fromEntries(rows.attendance_reports.filter(a=>a.session_id===x.id).map(a=>[String(a.room_id),{by:String(a.submitted_by),at:String(a.submitted_at)}]))}))};return {state,owner:campus.owner,revision:campus.revision};
}
export async function saveCampus(before:State,after:State,revision:number,accounts:{id:string;role:string;hash:string}[]=[]){validateDivisionCapacity(after);const db=raw(),old=flatten(before),next=flatten(after),commands=[];const guard='EXISTS (SELECT 1 FROM campus WHERE id=1 AND revision=?)';
 const reseated=new Set(after.sessions.filter(s=>JSON.stringify(s.seats)!==JSON.stringify(before.sessions.find(b=>b.id===s.id)?.seats||[])).map(s=>s.id));
 for(const id of reseated){commands.push(db.prepare(`DELETE FROM attendance_reports WHERE session_id=? AND ${guard}`).bind(id,revision));commands.push(db.prepare(`DELETE FROM attendance WHERE session_id=? AND ${guard}`).bind(id,revision));commands.push(db.prepare(`DELETE FROM seat_allocations WHERE session_id=? AND ${guard}`).bind(id,revision));}
 // All statements run in one D1 transaction. The revision guard rejects stale writes.
 for(const [table,,keys] of [...configs].reverse()){const current=new Set(next[table].map(r=>JSON.stringify(keys.map(k=>r[k]))));for(const row of old[table])if(!current.has(JSON.stringify(keys.map(k=>row[k]))))commands.push(db.prepare(`DELETE FROM ${table} WHERE ${keys.map(k=>`${k}=?`).join(' AND ')} AND ${guard}`).bind(...keys.map(k=>row[k]),revision));}
 for(const [table,cols,keys] of configs){const previous=new Map(old[table].map(r=>[JSON.stringify(keys.map(k=>r[k])),JSON.stringify(r)]));for(const row of next[table]){if(previous.get(JSON.stringify(keys.map(k=>row[k])))===JSON.stringify(row)&&!((table==='seat_allocations'||table==='attendance'||table==='attendance_reports')&&reseated.has(String(row.session_id))))continue;const updates=cols.filter(c=>!(keys as readonly string[]).includes(c)).map(c=>`${c}=excluded.${c}`);commands.push(db.prepare(`INSERT INTO ${table} (${cols.join(',')}) SELECT ${cols.map(()=>'?').join(',')} WHERE ${guard} ON CONFLICT (${keys.join(',')}) ${updates.length?'DO UPDATE SET '+updates.join(','):'DO NOTHING'}`).bind(...cols.map(c=>row[c]),revision));}}
 for(const account of accounts){commands.push(db.prepare(`INSERT INTO accounts (id,role,person_id,email,password_hash) SELECT ?,?,?,NULL,? WHERE ${guard} ON CONFLICT(id) DO UPDATE SET password_hash=excluded.password_hash`).bind(account.id,account.role,account.id,account.hash,revision));commands.push(db.prepare(`DELETE FROM auth_sessions WHERE account_id=? AND ${guard}`).bind(account.id,revision));}
 commands.push(db.prepare(`DELETE FROM accounts WHERE ((role='student' AND person_id NOT IN (SELECT id FROM students)) OR (role='faculty' AND person_id NOT IN (SELECT id FROM faculty))) AND ${guard}`).bind(revision));
 commands.push(db.prepare('UPDATE campus SET revision=revision+1 WHERE id=1 AND revision=?').bind(revision));const result=await db.batch(commands);if(!result.at(-1)?.meta.changes)throw Error('Another change was saved. Reload and retry.');
}
