'use client';
import {useState} from 'react';
import {batchDisplayName,semesterCount,type Batch,type State} from '@/lib/exams';
import {Dialog,DialogContent,DialogTitle,DialogDescription} from '@/components/ui/dialog';

type BatchForm=Partial<Batch>&{generateStudents?:boolean};
const divisions=Array.from({length:26},(_,i)=>String.fromCharCode(65+i));

export default function BatchManager({data,busy,error,save,remove}:{data:State;busy:boolean;error:string;save:(record:unknown)=>Promise<boolean>;remove:(id:string)=>void}){
 const [form,setForm]=useState<BatchForm|null>(null);
 const nextDivision=(department:string,admissionYear:number)=>{
  const used=new Set(data.batches.filter(batch=>batch.department===department&&batch.admissionYear===admissionYear).map(batch=>batch.division||'A'));
  return divisions.find(division=>!used.has(division))||'A';
 };
 const startBatch=()=>{
  const admissionYear=Math.max(new Date().getFullYear(),...data.batches.map(batch=>batch.admissionYear))+1;
  setForm({department:'BCA',admissionYear,division:nextDivision('BCA',admissionYear),semester:1,status:'Active',generateStudents:false});
 };
 async function submit(event:React.FormEvent){event.preventDefault();if(form&&await save(form))setForm(null);}

 return <section className="panel">
  <div className="panelhead"><div><h2>Admission years & semesters</h2><p>BCA · 4 years · S1–S8 &nbsp; | &nbsp; MCA · 2 years · S1–S4</p></div><button className="primary" disabled={busy} onClick={startBatch}>Add upcoming-year batch</button></div>
  <p>Each division is a separate group of up to 60 students. Advance a cohort when the new semester begins; all its students move together.</p>
  <div className="batch-grid">{[...data.batches].sort((a,b)=>a.department.localeCompare(b.department)||b.admissionYear-a.admissionYear||(a.division||'A').localeCompare(b.division||'A')).map(batch=>{
   const count=semesterCount(batch.department);
   return <article className="batch-card" key={batch.id}>
    <div><span className="eyebrow">{batch.department} · {count/2} YEARS</span><h3>{batchDisplayName(batch)}</h3><p>Admission batch {batch.id} · {batch.admissionYear}–{batch.admissionYear+count/2} · {data.students.filter(student=>student.batch===batch.id).length} students{batch.status==='Completed'?' · Completed':''}</p></div>
    <div className="semester-track">{Array.from({length:count},(_,i)=><span key={i} className={i+1===batch.semester?'current':''}>S{i+1}</span>)}</div>
    <div className="record-actions"><button disabled={busy||batch.status==='Completed'||batch.semester>=count} onClick={()=>void save({...batch,semester:batch.semester+1})}>{batch.semester<count?`Advance to S${batch.semester+1}`:'Final semester'}</button><button disabled={busy} onClick={()=>setForm({...batch,division:batch.division||'A'})}>Edit semester / status</button><button disabled={busy} onClick={()=>remove(batch.id)}>Delete batch</button></div>
   </article>;
  })}</div>
  <Dialog open={!!form} onOpenChange={open=>{if(!open)setForm(null)}}><DialogContent className="editor"><DialogTitle>{form?.id?'Edit batch':'Add admission batch'}</DialogTitle><DialogDescription>Choose the cohort’s semester and division. Each division can hold up to 60 students. Changing semester clears any seating plan that includes this cohort.</DialogDescription>{form&&<form onSubmit={submit}>
   <label>Course<select disabled={!!form.id} value={form.department||'BCA'} onChange={event=>{const department=event.target.value as 'BCA'|'MCA';setForm({...form,department,semester:1,division:nextDivision(department,Number(form.admissionYear))});}}><option>BCA</option><option>MCA</option></select></label>
   <label>Admission year<input type="number" required min={2022} max={2100} disabled={!!form.id} value={form.admissionYear||''} onChange={event=>{const admissionYear=Number(event.target.value);setForm({...form,admissionYear,division:nextDivision(form.department||'BCA',admissionYear)});}}/></label>
   <label>Division<select disabled={!!form.id} value={form.division||'A'} onChange={event=>setForm({...form,division:event.target.value})}>{divisions.map(division=><option key={division}>{division}</option>)}</select></label>
   <label>Current semester<select value={form.semester||1} onChange={event=>setForm({...form,semester:Number(event.target.value)})}>{Array.from({length:semesterCount(form.department||'BCA')},(_,i)=><option value={i+1} key={i}>S{i+1}</option>)}</select></label>
   <label>Status<select value={form.status||'Active'} onChange={event=>setForm({...form,status:event.target.value as 'Active'|'Completed'})}><option>Active</option><option>Completed</option></select></label>
   {!form.id&&<label className="checkbox-label"><input type="checkbox" checked={!!form.generateStudents} onChange={event=>setForm({...form,generateStudents:event.target.checked})}/> Generate 60 sample students in this division</label>}
   {!form.id&&!form.generateStudents&&<p>The division starts empty. Enroll students from the Students tab.</p>}
   {error&&<p role="alert" className="formerror">{error}</p>}
   <button className="primary" disabled={busy}>{busy?'Saving…':'Save batch'}</button>
  </form>}</DialogContent></Dialog>
 </section>;
}