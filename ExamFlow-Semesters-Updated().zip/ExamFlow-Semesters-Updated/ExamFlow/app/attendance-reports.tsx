'use client';
import {Table,TableHeader,TableBody,TableRow,TableHead,TableCell} from '@/components/ui/table';
import type {Session,State} from '@/lib/exams';
import type {Student} from '@/lib/exams';

type AttendanceStatus='Not marked'|'Present'|'Absent';
const csvCell=(value:unknown)=>'"'+String(value??'').replace(/^[=+@-]/,"'$&").replaceAll('"','""')+'"';
function downloadCsv(filename:string,rows:unknown[][]){const contents=rows.map(row=>row.map(csvCell).join(',')).join('\r\n');const url=URL.createObjectURL(new Blob([contents],{type:'text/csv'}));const link=document.createElement('a');link.href=url;link.download=filename;link.click();URL.revokeObjectURL(url);}

export function FacultyAttendanceReport({session,room,students,busy,mark,submit}:{session:Session;room:string;students:Student[];busy:boolean;mark:(studentId:string,status:AttendanceStatus)=>void;submit:()=>Promise<boolean>}){
 const seats=session.seats.filter(seat=>seat.room===room).sort((a,b)=>a.number-b.number);
 const report=session.attendanceReports[room];
 const present=seats.filter(seat=>session.attendance[seat.studentId]?.status==='Present').length;
 const absent=seats.filter(seat=>session.attendance[seat.studentId]?.status==='Absent').length;
 const complete=seats.length>0&&seats.every(seat=>['Present','Absent'].includes(session.attendance[seat.studentId]?.status||''));
 const rows=()=>[['Exam series','Date','Room','Seat','Roll number','Student','Subject','Attendance'],...seats.map(seat=>{const student=students.find(person=>person.id===seat.studentId)!;return [session.title,session.date,room,seat.number,student.roll,student.name,session.subjects[student.batch],session.attendance[student.id]?.status||'Not marked'];})];
 return <article className="panel attendance-report" key={session.id+room}>
  <div className="panelhead"><div><h2>Classroom {room}</h2><p>{session.title} · {session.date} · {session.start}–{session.end} IST</p></div><div className="attendancecounts"><strong>{present} present</strong><strong>{absent} absent</strong><span>{seats.length-present-absent} not marked</span></div></div>
  {report&&<p className="report-submitted" role="status">Report sent to administrator by {report.by} at {new Date(report.at).toLocaleString()}</p>}
  <Table><TableHeader><TableRow>{['Seat','Student','Roll number','Subject','Attendance'].map(heading=><TableHead key={heading}>{heading}</TableHead>)}</TableRow></TableHeader><TableBody>{seats.map(seat=>{const student=students.find(person=>person.id===seat.studentId)!;const current=(session.attendance[student.id]?.status||'Not marked') as AttendanceStatus;return <TableRow key={seat.studentId}><TableCell>{seat.number}</TableCell><TableCell>{student.name}</TableCell><TableCell>{student.roll}</TableCell><TableCell>{session.subjects[student.batch]}</TableCell><TableCell><fieldset disabled={busy||!!report} className="attendancebuttons" aria-label={`${student.name} attendance`}>{(['Not marked','Present','Absent'] as AttendanceStatus[]).map(status=><button type="button" className={current===status?'selected':''} key={status} onClick={()=>mark(student.id,status)}>{status}</button>)}</fieldset></TableCell></TableRow>;})}</TableBody></Table>
  <div className="report-actions"><button type="button" disabled={busy||!!report||!complete} onClick={()=>void submit()}>{report?'Report submitted':busy?'Saving…':'Save and send report'}</button><button type="button" disabled={!seats.length} onClick={()=>downloadCsv(`attendance-${session.id}-${room}.csv`,rows())}>Download CSV</button><button type="button" disabled={!seats.length} onClick={()=>window.print()}>Print report</button></div>
 </article>;
}

export function AdminAttendanceReports({data}:{data:State}){
 const reports=data.sessions.flatMap(session=>Object.entries(session.attendanceReports).map(([room,report])=>({session,room,report}))).sort((a,b)=>a.session.date.localeCompare(b.session.date)||a.room.localeCompare(b.room));
 return <section className="panel"><div className="panelhead"><div><h2>Submitted attendance reports</h2><p>{reports.length} reports received</p></div></div>{!reports.length?<div className="empty"><h3>No reports submitted</h3><p>Faculty reports will appear here after they save and send classroom attendance.</p></div>:reports.map(({session,room,report})=>{
    const seats=session.seats.filter(seat=>seat.room===room).sort((a,b)=>a.number-b.number);
    const present=seats.filter(seat=>session.attendance[seat.studentId]?.status==='Present').length;
    const absent=seats.filter(seat=>session.attendance[seat.studentId]?.status==='Absent').length;
    const rows=()=>[['Exam series','Date','Room','Seat','Roll number','Student','Subject','Attendance'],...seats.map(seat=>{const student=data.students.find(person=>person.id===seat.studentId)!;return [session.title,session.date,room,seat.number,student.roll,student.name,session.subjects[student.batch],session.attendance[student.id]?.status||'Not marked'];})];
    return <article className="attendance-report admin-attendance-report" key={session.id+room}><div className="panelhead"><div><h3>{session.title} · Classroom {room}</h3><p>{session.date} · {session.start}–{session.end} IST · Submitted by {report.by} · {new Date(report.at).toLocaleString()}</p></div><div className="attendancecounts"><strong>{present} present</strong><strong>{absent} absent</strong></div></div><Table><TableHeader><TableRow>{['Seat','Student','Roll number','Subject','Attendance'].map(heading=><TableHead key={heading}>{heading}</TableHead>)}</TableRow></TableHeader><TableBody>{seats.map(seat=>{const student=data.students.find(person=>person.id===seat.studentId)!;return <TableRow key={seat.studentId}><TableCell>{seat.number}</TableCell><TableCell>{student.name}</TableCell><TableCell>{student.roll}</TableCell><TableCell>{session.subjects[student.batch]}</TableCell><TableCell>{session.attendance[student.id]?.status||'Not marked'}</TableCell></TableRow>;})}</TableBody></Table><div className="report-actions"><button type="button" onClick={()=>downloadCsv(`attendance-${session.id}-${room}.csv`,rows())}>Download CSV</button><button type="button" onClick={()=>window.print()}>Print report</button></div></article>;
 })}</section>;
}
