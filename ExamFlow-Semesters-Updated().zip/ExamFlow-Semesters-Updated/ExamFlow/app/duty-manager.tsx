'use client';
import {useEffect,useState} from 'react';
import type {Faculty,Session} from '@/lib/exams';

type Duties=Record<string,string[]>;
export default function DutyManager({session,faculty,busy,save}:{session:Session;faculty:Faculty[];busy:boolean;save:(duties:Duties)=>Promise<boolean>}){
 const rooms=[...new Set(session.seats.map(seat=>seat.room))].sort();
 const initial=()=>Object.fromEntries(rooms.map(room=>[room,[...(session.duties[room]||[]).slice(0,2),'',''].slice(0,2)]));
 const [editing,setEditing]=useState(false);
 const [draft,setDraft]=useState<Duties>(initial);
 useEffect(()=>{setDraft(initial());setEditing(false);},[session.id,session.duties,session.seats]);
 const update=(room:string,slot:number,id:string)=>setDraft(current=>({...current,[room]:current[room].map((value,index)=>index===slot?id:value)}));
 const complete=rooms.length>0&&rooms.every(room=>draft[room]?.length===2&&draft[room][0]&&draft[room][1]&&draft[room][0]!==draft[room][1])&&new Set(Object.values(draft).flat()).size===rooms.length*2;
 async function submit(event:React.FormEvent){event.preventDefault();if(complete&&await save(draft))setEditing(false);}

 const reportsSubmitted=Object.keys(session.attendanceReports).length>0;
 return <section className="duty-manager"><div className="duty-manager-head"><div><h3>Examination invigilators</h3><p>{session.published?'Edit faculty assignments if someone is unavailable. Assignments lock after a report is submitted.':'Assign two different faculty members to every classroom before publishing.'}</p></div><button type="button" disabled={busy||reportsSubmitted||rooms.length===0} onClick={()=>{setDraft(initial());setEditing(value=>!value)}}>{editing?'Cancel':Object.keys(session.duties).length?'Edit invigilators':'Assign faculty'}</button></div>
  {!rooms.length?<p>Generate seating to see the classrooms that need invigilators.</p>:editing?<form onSubmit={submit}>
   <div className="duty-room-grid">{rooms.map(room=><article className="duty-room" key={room}><h4>Classroom {room}</h4>{[0,1].map(slot=>{
    const used=Object.entries(draft).flatMap(([otherRoom,ids])=>ids.filter((id,index)=>id&&!(otherRoom===room&&index===slot)));
    return <label key={slot}>Invigilator {slot+1}<select aria-label={`${room} invigilator ${slot+1}`} value={draft[room]?.[slot]||''} onChange={event=>update(room,slot,event.target.value)}><option value="">Choose faculty</option>{faculty.map(person=><option key={person.id} value={person.id} disabled={used.includes(person.id)}>{person.name}</option>)}</select></label>;
   })}</article>)}</div>
   <button className="primary" disabled={busy||!complete}>{busy?'Saving…':'Save invigilators'}</button>
  </form>:<div className="duty-room-grid">{rooms.map(room=><div className="duty-room" key={room}><strong>Classroom {room}</strong><span>{(session.duties[room]||[]).map(id=>faculty.find(person=>person.id===id)?.name||'Unassigned').join(' · ')||'Not assigned'}</span></div>)}</div>}
 </section>;
}