import {database,sameOrigin,cookieToken,sessionCookie} from '@/lib/auth';
import {tokenHash} from '@/lib/passwords';
export async function POST(request:Request){try{sameOrigin(request);const token=cookieToken(request);if(token)await database().prepare('DELETE FROM auth_sessions WHERE token_hash=?').bind(await tokenHash(token)).run();return Response.json({ok:true},{headers:{'Set-Cookie':sessionCookie(request,'',0),'Cache-Control':'no-store'}});}catch{return Response.json({error:'Logout failed. Please retry.'},{status:400});}}
