import {database,sameOrigin,sessionCookie} from '@/lib/auth';
import {loginName} from '@/lib/exams';
import {verifyPassword,tokenHash} from '@/lib/passwords';
export async function POST(request:Request){try{
 sameOrigin(request);const body=await request.json() as {username?:string;email?:string;role:string;password:string};const username=String(body.username ?? body.email ?? '').trim().toLowerCase();const normalizedUser=username.replace(/[^a-z]/g,'');
 if(!['admin','faculty','student'].includes(body.role)||normalizedUser.length===0||normalizedUser.length>150)throw Error('Invalid login.');
 const db=database(),key=await tokenHash(normalizedUser+':'+body.role);
 const limit=await db.prepare('SELECT attempts,until_at FROM login_attempts WHERE key=?').bind(key).first<{attempts:number;until_at:number}>();
 if(limit&&limit.attempts>=10&&limit.until_at>Date.now())return Response.json({error:'Too many attempts. Try again in 15 minutes.'},{status:429});
 await db.prepare(`INSERT INTO login_attempts (key,attempts,until_at) VALUES (?,1,?) ON CONFLICT(key) DO UPDATE SET attempts=CASE WHEN until_at<? THEN 1 ELSE attempts+1 END,until_at=CASE WHEN until_at<? THEN excluded.until_at ELSE until_at END`).bind(key,Date.now()+900000,Date.now(),Date.now()).run();
 const candidatesResponse=await db.prepare(`SELECT a.id,a.password_hash,st.name AS student_name,f.name AS faculty_name,a.email AS admin_email FROM accounts a LEFT JOIN students st ON a.role='student' AND st.id=a.person_id LEFT JOIN faculty f ON a.role='faculty' AND f.id=a.person_id WHERE a.role=?`).bind(body.role).all<{id:string;password_hash:string;student_name:string|null;faculty_name:string|null;admin_email:string|null}>();
 const candidates=(candidatesResponse as {results?: Array<{id:string;password_hash:string;student_name:string|null;faculty_name:string|null;admin_email:string|null}>}).results ?? [];
 const account=candidates.find(candidate=>{
  const generated=loginName(candidate.student_name || candidate.faculty_name || candidate.admin_email || candidate.id || '');
  return normalizedUser===generated || normalizedUser===candidate.id.toLowerCase().replace(/[^a-z]/g,'') || (body.role==='admin'&&normalizedUser==='admin');
 });
 const dummy='pbkdf2$100000$00000000000000000000000000000000$'+'0'.repeat(64);
 const valid=await verifyPassword(body.password,account?.password_hash||dummy);
 if(!account||!valid)return Response.json({error:'Username, password or selected module is incorrect.'},{status:401});
 const token=Array.from(crypto.getRandomValues(new Uint8Array(32)),b=>b.toString(16).padStart(2,'0')).join('');
 await db.batch([db.prepare('DELETE FROM login_attempts WHERE key=?').bind(key),db.prepare('DELETE FROM auth_sessions WHERE expires_at<?').bind(Date.now()),db.prepare('INSERT INTO auth_sessions (token_hash,account_id,expires_at) VALUES (?,?,?)').bind(await tokenHash(token),account.id,Date.now()+8*3600000)]);
 return Response.json({role:body.role},{headers:{'Set-Cookie':sessionCookie(request,token,28800),'Cache-Control':'no-store'}});
}catch(error){
 console.error('AUTH LOGIN ERROR', error);
 return Response.json({error:'Unable to sign in. Check that the database has been set up.'},{status:400});
}}

