import Workspace from '../workspace';
export default function Portal(){return <Workspace/>;}
