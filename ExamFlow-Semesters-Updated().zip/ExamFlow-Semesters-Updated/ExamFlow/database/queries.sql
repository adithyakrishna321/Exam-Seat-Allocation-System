-- Student exam information (replace the roll number).
SELECT s.name,s.roll,s.batch,e.exam_date,e.start_time,e.end_time,
       sub.subject,a.room_id,a.bench,a.position,a.seat_number
FROM students s
JOIN seat_allocations a ON a.student_id=s.id
JOIN exam_sessions e ON e.id=a.session_id
JOIN exam_subjects sub ON sub.session_id=e.id AND sub.batch=s.batch
WHERE s.roll='MLM23BCA01' AND e.published=1
ORDER BY e.exam_date,e.start_time;

-- Invigilation duties and absence counts. Not marked is not an absence.
SELECT f.name,d.room_id,e.exam_date,e.start_time,e.end_time,
       COUNT(a.student_id) AS allocated_students,
       SUM(CASE WHEN t.status='Present' THEN 1 ELSE 0 END) AS present,
       SUM(CASE WHEN t.status='Absent' THEN 1 ELSE 0 END) AS absent,
       SUM(CASE WHEN t.status IS NULL THEN 1 ELSE 0 END) AS not_marked
FROM invigilator_assignments d
JOIN faculty f ON f.id=d.faculty_id
JOIN exam_sessions e ON e.id=d.session_id
JOIN seat_allocations a ON a.session_id=d.session_id AND a.room_id=d.room_id
LEFT JOIN attendance t ON t.session_id=a.session_id AND t.student_id=a.student_id
GROUP BY f.id,d.session_id,d.room_id;

-- Per-room seating roster.
SELECT a.room_id,a.bench,a.position,a.seat_number,s.roll,s.name,s.batch
FROM seat_allocations a JOIN students s ON s.id=a.student_id
WHERE a.session_id='session-1' AND a.room_id='R01'
ORDER BY a.bench,a.position;
