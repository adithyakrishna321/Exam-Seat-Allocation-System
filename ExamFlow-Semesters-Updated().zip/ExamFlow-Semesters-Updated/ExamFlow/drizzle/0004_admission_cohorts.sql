ALTER TABLE `batches` ADD `admission_year` integer DEFAULT 2026 NOT NULL;
--> statement-breakpoint
ALTER TABLE `batches` ADD `status` text DEFAULT 'Active' NOT NULL;