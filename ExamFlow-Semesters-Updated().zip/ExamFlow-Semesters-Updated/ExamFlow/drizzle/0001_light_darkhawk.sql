CREATE TABLE `seat_allocations` (
	`session_id` text NOT NULL,
	`student_id` text NOT NULL,
	`room_id` text NOT NULL,
	`bench` integer NOT NULL,
	`position` integer NOT NULL,
	`seat_number` integer NOT NULL,
	PRIMARY KEY(`session_id`, `student_id`),
	FOREIGN KEY (`session_id`) REFERENCES `exam_sessions`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`student_id`) REFERENCES `students`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`room_id`) REFERENCES `classrooms`(`id`) ON UPDATE no action ON DELETE no action,
	CONSTRAINT "valid_bench" CHECK("seat_allocations"."bench" between 1 and 12),
	CONSTRAINT "valid_position" CHECK("seat_allocations"."position" between 1 and 5),
	CONSTRAINT "valid_seat_number" CHECK("seat_allocations"."seat_number" = ("seat_allocations"."bench"-1)*5+"seat_allocations"."position")
);
--> statement-breakpoint
CREATE UNIQUE INDEX `unique_session_seat` ON `seat_allocations` (`session_id`,`room_id`,`seat_number`);--> statement-breakpoint
CREATE TABLE `attendance` (
	`session_id` text NOT NULL,
	`student_id` text NOT NULL,
	`status` text NOT NULL,
	`marked_by` text NOT NULL,
	`marked_at` text NOT NULL,
	PRIMARY KEY(`session_id`, `student_id`),
	FOREIGN KEY (`session_id`,`student_id`) REFERENCES `seat_allocations`(`session_id`,`student_id`) ON UPDATE no action ON DELETE no action,
	CONSTRAINT "valid_attendance_status" CHECK("attendance"."status" in ('Present','Absent'))
);
--> statement-breakpoint
CREATE TABLE `batches` (
	`id` text PRIMARY KEY NOT NULL,
	`department` text NOT NULL,
	`semester` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `campus` (
	`id` integer PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`revision` integer DEFAULT 0 NOT NULL,
	`initialized` integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE TABLE `classrooms` (
	`id` text PRIMARY KEY NOT NULL,
	`bench_count` integer DEFAULT 12 NOT NULL,
	`seats_per_bench` integer DEFAULT 5 NOT NULL
);
--> statement-breakpoint
CREATE TABLE `exam_sessions` (
	`id` text PRIMARY KEY NOT NULL,
	`title` text NOT NULL,
	`exam_date` text NOT NULL,
	`start_time` text NOT NULL,
	`end_time` text NOT NULL,
	`published` integer DEFAULT 0 NOT NULL,
	CONSTRAINT "valid_exam_time" CHECK("exam_sessions"."start_time" < "exam_sessions"."end_time")
);
--> statement-breakpoint
CREATE TABLE `exam_subjects` (
	`session_id` text NOT NULL,
	`batch` text NOT NULL,
	`subject` text NOT NULL,
	PRIMARY KEY(`session_id`, `batch`),
	FOREIGN KEY (`session_id`) REFERENCES `exam_sessions`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`batch`) REFERENCES `batches`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE TABLE `faculty` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`email` text
);
--> statement-breakpoint
CREATE UNIQUE INDEX `faculty_email_unique` ON `faculty` (`email`);--> statement-breakpoint
CREATE TABLE `invigilator_assignments` (
	`session_id` text NOT NULL,
	`room_id` text NOT NULL,
	`faculty_id` text NOT NULL,
	PRIMARY KEY(`session_id`, `faculty_id`),
	FOREIGN KEY (`session_id`) REFERENCES `exam_sessions`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`room_id`) REFERENCES `classrooms`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`faculty_id`) REFERENCES `faculty`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE TABLE `students` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`roll` text NOT NULL,
	`batch` text NOT NULL,
	`academic_year` text NOT NULL,
	`email` text,
	FOREIGN KEY (`batch`) REFERENCES `batches`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `students_roll_unique` ON `students` (`roll`);--> statement-breakpoint
CREATE UNIQUE INDEX `students_email_unique` ON `students` (`email`);